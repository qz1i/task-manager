document.addEventListener("DOMContentLoaded", () => {
  const input = document.getElementById("task-input");
  const timeInput = document.getElementById("task-time");
  const addBtn = document.getElementById("add-task-btn");
  const taskList = document.getElementById("task-list");
  const counter = document.getElementById("task-counter");
  const saveBtn = document.getElementById("save-btn");
  const notifyBtn = document.getElementById("notification-btn");

  addBtn.addEventListener("click", () => {
    const text = input.value.trim();
    const time = timeInput.value;
    if (text !== "") {
      addTask(text, time);
      input.value = "";
      timeInput.value = "";
    }
  });

  notifyBtn.addEventListener("click", () => {
    Notification.requestPermission().then(permission => {
      if (permission === "granted") {
        new Notification("📌 لا تنسَ مهامك اليوم!");
      }
    });
  });

  saveBtn.addEventListener("click", () => {
    const tasks = [];
    const items = taskList.querySelectorAll("li span");
    items.forEach(span => {
      tasks.push(span.textContent.trim());
    });

    const blob = new Blob([JSON.stringify(tasks, null, 2)], { type: "application/json" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = "tasks.json";
    link.click();
  });

  function addTask(text, time) {
    const li = document.createElement("li");

    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.addEventListener("change", updateCounter);

    const span = document.createElement("span");
    span.textContent = `${text}${time ? ` 🕒 ${time}` : ""}`;

    const deleteBtn = document.createElement("button");
    deleteBtn.textContent = "❌";
    deleteBtn.className = "delete-btn";
    deleteBtn.addEventListener("click", () => {
      li.remove();
      updateCounter();
    });

    li.appendChild(checkbox);
    li.appendChild(span);
    li.appendChild(deleteBtn);
    taskList.appendChild(li);

    if (time) {
      scheduleNotification(text, time);
    }

    updateCounter();
  }

  function updateCounter() {
    const allTasks = taskList.querySelectorAll("li");
    const doneTasks = Array.from(allTasks).filter(task =>
      task.querySelector("input[type='checkbox']").checked
    );
    if (allTasks.length === 0) {
      counter.textContent = "لا توجد مهام بعد";
    } else {
      counter.textContent = `أنجزت ${doneTasks.length} من ${allTasks.length} مهام ✅`;
    }
  }

  function scheduleNotification(taskText, timeStr) {
    if (Notification.permission !== "granted") return;

    const [hour, minute] = timeStr.split(":").map(Number);
    const now = new Date();
    const taskTime = new Date();
    taskTime.setHours(hour, minute, 0, 0);
    if (taskTime < now) {
      taskTime.setDate(taskTime.getDate() + 1);
    }
    const delay = taskTime.getTime() - now.getTime();

    setTimeout(() => {
      new Notification("⏰ تذكير بالمهام", {
        body: `حان وقت: ${taskText}`,
        icon: "https://cdn-icons-png.flaticon.com/512/190/190411.png"
      });
    }, delay);
  }
});
